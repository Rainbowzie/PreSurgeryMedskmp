# Pet Medication API

A tiny Java (Spark) API that exposes your pet medication guide online.

## Endpoints
- `GET /health` → `{"status":"ok"}`
- `GET /meds?type=dog|cat&weight=NUMBER` → JSON with recommendations

## Build locally
```bash
mvn -DskipTests=true package
java -jar target/petmed-api-1.0.0-jar-with-dependencies.jar
```

## Deploy on Render
- Build Command: `mvn -DskipTests=true package`
- Start Command: `java -jar target/petmed-api-1.0.0-jar-with-dependencies.jar`
