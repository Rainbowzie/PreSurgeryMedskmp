package com.example.petmed;

import java.util.ArrayList;
import java.util.List;

public class MedicationService {

    public static class MedResponse {
        public String petType;
        public double weight;
        public List<String> recommendations = new ArrayList<>();
        public List<String> warnings = new ArrayList<>();
    }

    public MedResponse getMedications(String petType, double weight) {
        MedResponse resp = new MedResponse();
        resp.petType = petType;
        resp.weight = weight;

        if (petType == null) {
            resp.warnings.add("Missing pet type. Use 'dog' or 'cat'.");
            return resp;
        }

        if (petType.equalsIgnoreCase("cat")) {
            resp.recommendations.addAll(gabapentinForCat(weight));
        } else if (petType.equalsIgnoreCase("dog")) {
            resp.recommendations.addAll(gabapentinForDog(weight));
            resp.recommendations.addAll(cereniaForDog(weight));
            resp.recommendations.addAll(trazodoneForDog(weight));
        } else {
            resp.warnings.add("Invalid pet type. Use 'dog' or 'cat'.");
        }
        return resp;
    }

    private List<String> gabapentinForCat(double weight) {
        List<String> out = new ArrayList<>();
        out.add("--- Gabapentin for Cat ---");
        if (weight >= 4 && weight <= 6.99) {
            out.add("Gabapentin 50mg/ml #2. Give 1ml night before and morning of surgery.");
        } else if (weight >= 7 && weight <= 9.99) {
            out.add("Gabapentin 50mg/ml #3. Give 1.5ml night before and morning of surgery.");
        } else if (weight >= 10 && weight <= 16.99) {
            out.add("Gabapentin 100mg #2. Give 1 by mouth night before and morning of surgery.");
        } else if (weight >= 17 && weight <= 27.99) {
            out.add("Gabapentin 100mg #4. Give 2 by mouth night before and morning of surgery.");
        } else {
            out.add("No gabapentin dosage recommendation for this weight.");
        }
        return out;
    }

    private List<String> gabapentinForDog(double weight) {
        List<String> out = new ArrayList<>();
        out.add("--- Gabapentin for Dog ---");
        if (weight >= 2 && weight <= 3.99) {
            out.add("Gabapentin 50mg/ml #1. Give 0.5ml night before and morning of surgery.");
        } else if (weight >= 4 && weight <= 6.99) {
            out.add("Gabapentin 50mg/ml #2. Give 1ml night before and morning of surgery.");
        } else if (weight >= 7 && weight <= 9.99) {
            out.add("Gabapentin 50mg/ml #3. Give 1.5ml night before and morning of surgery.");
        } else if (weight >= 10 && weight <= 16.99) {
            out.add("Gabapentin 100mg #2. Give 1 by mouth night before and morning of surgery.");
        } else if (weight >= 17 && weight <= 27.99) {
            out.add("Gabapentin 100mg #4. Give 2 by mouth night before and morning of surgery.");
        } else if (weight >= 28 && weight <= 38.99) {
            out.add("Gabapentin 600mg #1. Give 1/2 by mouth night before and morning of surgery.");
        } else if (weight >= 39 && weight <= 49.99) {
            out.add("Gabapentin 800mg #1. Give 1/2 by mouth night before and morning of surgery.");
        } else if (weight >= 50 && weight <= 71.99) {
            out.add("Gabapentin 600mg #2. Give 1 by mouth night before and morning of surgery.");
        } else if (weight >= 72 && weight <= 93.99) {
            out.add("Gabapentin 800mg #2. Give 1 by mouth night before and morning of surgery.");
        } else if (weight >= 94 && weight <= 104.99) {
            out.add("Gabapentin 600mg #3. Give 1.5 by mouth night before and morning of surgery.");
        } else if (weight >= 105 && weight <= 137.99) {
            out.add("Gabapentin 600mg #4. Give 2 by mouth night before and morning of surgery.");
        } else if (weight >= 138 && weight <= 155.99) {
            out.add("Gabapentin 800mg #4. Give 2 by mouth night before and morning of surgery.");
        } else {
            out.add("No gabapentin dosage recommendation for this weight.");
        }
        return out;
    }

    private List<String> cereniaForDog(double weight) {
        List<String> out = new ArrayList<>();
        out.add("--- Cerenia for Dog ---");
        if (weight < 4) {
            out.add("Do not dispense.");
        } else if (weight <= 6.99) {
            out.add("Cerenia 16mg #1. Give 1/4 by mouth night before surgery.");
        } else if (weight <= 11.99) {
            out.add("Cerenia 16mg #1. Give 1/2 by mouth night before surgery.");
        } else if (weight <= 16.99) {
            out.add("Cerenia 24mg #1. Give 1/2 by mouth night before surgery.");
        } else if (weight <= 22.99) {
            out.add("Cerenia 16mg #1. Give 1 by mouth night before surgery.");
        } else if (weight <= 29.99) {
            out.add("Cerenia 24mg #1. Give 1 by mouth night before surgery.");
        } else if (weight <= 34.99) {
            out.add("Cerenia 60mg #1. Give 1/2 by mouth night before surgery.");
        } else if (weight <= 38.99) {
            out.add("Cerenia 16mg #2. Give 2 by mouth night before surgery.");
        } else if (weight <= 43.99) {
            out.add("Cerenia 24mg #2. Give 1.5 by mouth night before surgery.");
        } else if (weight <= 57.99) {
            out.add("Cerenia 24mg #2. Give 2 by mouth night before surgery.");
        } else if (weight <= 72.99) {
            out.add("Cerenia 60mg #1. Give 1 by mouth night before surgery.");
        } else if (weight <= 98.99) {
            out.add("Cerenia 160mg #1. Give 1/2 by mouth night before surgery.");
        } else if (weight <= 113.99) {
            out.add("Cerenia 60mg #2. Give 1.5 by mouth night before surgery.");
        } else if (weight <= 148.99) {
            out.add("Cerenia 60mg #2. Give 2 by mouth night before surgery.");
        } else if (weight <= 155.99) {
            out.add("Cerenia 160mg #2. Give 1 by mouth night before surgery.");
        } else {
            out.add("No Cerenia dosage recommendation for this weight.");
        }
        return out;
    }

    private List<String> trazodoneForDog(double weight) {
        List<String> out = new ArrayList<>();
        out.add("--- Trazodone for Dog ---");
        if (weight < 4) {
            out.add("Do not dispense.");
        } else if (weight <= 6.99) {
            out.add("Trazodone 50mg #1. Give 1/4 by mouth night before and morning of surgery.");
        } else if (weight <= 11.99) {
            out.add("Trazodone 50mg #1. Give 1/2 by mouth night before and morning of surgery.");
        } else if (weight <= 13.99) {
            out.add("Trazodone 50mg #2. Give 3/4 by mouth night before and morning of surgery.");
        } else if (weight <= 22.99) {
            out.add("Trazodone 50mg #2. Give 1 by mouth night before and morning of surgery.");
        } else if (weight <= 27.99) {
            out.add("Trazodone 50mg #3. Give 1.5 by mouth night before and morning of surgery.");
        } else if (weight <= 44.99) {
            out.add("Trazodone 100mg #2. Give 1 by mouth night before and morning of surgery.");
        } else if (weight <= 66.99) {
            out.add("Trazodone 100mg #3. Give 1.5 by mouth night before and morning of surgery.");
        } else if (weight <= 88.99) {
            out.add("Trazodone 100mg #4. Give 2 by mouth night before and morning of surgery.");
        } else if (weight <= 110.99) {
            out.add("Trazodone 100mg #5. Give 2.5 by mouth night before and morning of surgery.");
        } else if (weight <= 132.99) {
            out.add("Trazodone 100mg #6. Give 3 by mouth night before and morning of surgery.");
        } else if (weight <= 155.99) {
            out.add("Trazodone 100mg #8. Give 4 by mouth night before and morning of surgery.");
        } else {
            out.add("No Trazodone dosage recommendation for this weight.");
        }
        return out;
    }
}
