package com.example.petmed;

import static spark.Spark.*;
import com.google.gson.Gson;

public class App {
    public static void main(String[] args) {
        port(getAssignedPort());
        enableCORS();

        // Health check
        get("/health", (req, res) -> {
            res.type("application/json");
            return "{\"status\":\"ok\"}";
        });

        // GET /meds?type=dog&weight=22.5
        get("/meds", (req, res) -> {
            res.type("application/json");
            String type = req.queryParams("type");
            String w = req.queryParams("weight");

            if (w == null || w.isBlank()) {
                res.status(400);
                return "{\"error\":\"Missing 'weight' query param\"}";
            }
            double weight;
            try {
                weight = Double.parseDouble(w);
            } catch (NumberFormatException nfe) {
                res.status(400);
                return "{\"error\":\"'weight' must be a number\"}";
            }

            MedicationService svc = new MedicationService();
            MedicationService.MedResponse response = svc.getMedications(type, weight);
            return new Gson().toJson(response);
        });
    }

    private static int getAssignedPort() {
        String p = System.getenv("PORT");
        if (p != null) return Integer.parseInt(p);
        return 4567; // local dev
    }

    private static void enableCORS() {
        options("/*", (request, response) -> {
            String reqHeaders = request.headers("Access-Control-Request-Headers");
            if (reqHeaders != null) response.header("Access-Control-Allow-Headers", reqHeaders);
            String reqMethod = request.headers("Access-Control-Request-Method");
            if (reqMethod != null) response.header("Access-Control-Allow-Methods", reqMethod);
            return "OK";
        });
        before((request, response) -> {
            response.header("Access-Control-Allow-Origin", "*");
            response.header("Access-Control-Allow-Credentials", "true");
        });
    }
}
